# Quick Deployment Guide

## Step 1: Extract the Archive

```bash
tar -xzf scenario-1-deployment.tar.gz
cd scenario-1-deployment
```

## Step 2: Get Your DevOps Agent Webhook Credentials

1. Go to AWS DevOps Agent console
2. Navigate to your Agent Space
3. Create or view webhook configuration
4. Copy the webhook URL and secret

## Step 3: Set Environment Variables

```bash
export WEBHOOK_URL="https://event-ai.us-east-1.api.aws/webhook/generic/YOUR-ID"
export WEBHOOK_SECRET="YOUR-SECRET-KEY"
```

**Optional:** Override defaults if needed
```bash
export PRIMARY_REGION="us-east-1"        # Default: us-west-2
export ENVIRONMENT_NAME="my-app"         # Default: retail-store
```

## Step 4: Deploy

```bash
chmod +x deploy.sh
./deploy.sh
```

The script will:
- ✅ Auto-discover your NLB from kubectl/AWS
- ✅ Validate all inputs
- ✅ Create Lambda, CloudWatch alarm, Route 53 health check
- ✅ Store credentials securely in Secrets Manager

## Step 5: Test

```bash
# Trigger the alarm
aws cloudwatch set-alarm-state \
  --alarm-name retail-store-ui-endpoint-down \
  --state-value ALARM \
  --state-reason "Test" \
  --region us-east-1

# Check Lambda logs
aws logs tail /aws/lambda/retail-store-devops-agent-webhook --follow --region us-east-1
```

## Step 6: Cleanup (When Done)

```bash
./cleanup.sh
```

---

## Troubleshooting

**Auto-discovery failed?**
```bash
# Manually set NLB
export NLB_FULL_NAME="net/YOUR-NLB-NAME/YOUR-NLB-ID"
./deploy.sh
```

**Need help finding NLB?**
```bash
kubectl get svc -n ui ui
aws elbv2 describe-load-balancers --region us-east-1
```
