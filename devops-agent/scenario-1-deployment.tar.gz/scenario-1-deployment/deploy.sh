#!/bin/bash
set -eo pipefail

# Configuration Variables
PRIMARY_REGION="${PRIMARY_REGION:-us-west-2}"
ENVIRONMENT_NAME="${ENVIRONMENT_NAME:-retail-store}"
NLB_FULL_NAME="${NLB_FULL_NAME}"
NLB_DNS_NAME="${NLB_DNS_NAME}"
WEBHOOK_URL="${WEBHOOK_URL}"
WEBHOOK_SECRET="${WEBHOOK_SECRET}"
AUTH_TYPE="${AUTH_TYPE:-HMAC}"
ENABLE_ROUTE53="${ENABLE_ROUTE53:-true}"
USE_SECRETS_MANAGER="${USE_SECRETS_MANAGER:-true}"
SECRET_NAME="${SECRET_NAME:-${ENVIRONMENT_NAME}/devops-agent/webhook}"

# Auto-discovery function for NLB
auto_discover_nlb() {
    echo "🔍 Auto-discovering NLB details..."
    
    # Try to find NLB via kubectl
    if command -v kubectl &> /dev/null; then
        echo "   Checking kubectl for ui service..."
        NLB_DNS=$(kubectl get svc ui -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
        
        if [ -n "$NLB_DNS" ]; then
            echo "   ✅ Found NLB DNS from kubectl: $NLB_DNS"
            NLB_DNS_NAME="$NLB_DNS"
            
            # Get full NLB details from AWS
            echo "   Querying AWS for NLB details..."
            NLB_ARN=$(aws elbv2 describe-load-balancers \
                --region "$PRIMARY_REGION" \
                --query "LoadBalancers[?DNSName=='$NLB_DNS'].LoadBalancerArn" \
                --output text 2>/dev/null || echo "")
            
            if [ -n "$NLB_ARN" ]; then
                # Extract net/name/id from ARN
                # ARN format: arn:aws:elasticloadbalancing:region:account:loadbalancer/net/name/id
                NLB_FULL_NAME=$(echo "$NLB_ARN" | sed 's|.*loadbalancer/||')
                echo "   ✅ Extracted NLB_FULL_NAME: $NLB_FULL_NAME"
                return 0
            fi
        fi
    fi
    
    # Try to find NLB by searching for k8s-ui pattern
    echo "   Searching for NLB with 'k8s-ui' pattern..."
    NLB_INFO=$(aws elbv2 describe-load-balancers \
        --region "$PRIMARY_REGION" \
        --query "LoadBalancers[?contains(LoadBalancerName, 'k8s-ui')] | [0].[LoadBalancerArn,DNSName]" \
        --output text 2>/dev/null || echo "")
    
    if [ -n "$NLB_INFO" ] && [ "$NLB_INFO" != "None" ]; then
        NLB_ARN=$(echo "$NLB_INFO" | awk '{print $1}')
        NLB_DNS=$(echo "$NLB_INFO" | awk '{print $2}')
        NLB_FULL_NAME=$(echo "$NLB_ARN" | sed 's|.*loadbalancer/||')
        NLB_DNS_NAME="$NLB_DNS"
        echo "   ✅ Found NLB_FULL_NAME: $NLB_FULL_NAME"
        echo "   ✅ Found NLB_DNS_NAME: $NLB_DNS_NAME"
        return 0
    fi
    
    echo "   ⚠️  Could not auto-discover NLB"
    return 1
}

# Validation Function
validate_variables() {
    local errors=0
    
    echo "=== Validating Configuration ==="
    
    # Auto-discover NLB if not provided
    if [ -z "$NLB_FULL_NAME" ]; then
        echo "NLB_FULL_NAME not set, attempting auto-discovery..."
        if auto_discover_nlb; then
            echo "✅ Auto-discovery successful"
        else
            echo "❌ ERROR: NLB_FULL_NAME is required and auto-discovery failed"
            echo ""
            echo "   Manual setup:"
            echo "   1. Get NLB DNS: kubectl get svc ui -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'"
            echo "   2. Get NLB ARN: aws elbv2 describe-load-balancers --region $PRIMARY_REGION"
            echo "   3. Extract from ARN: arn:aws:...loadbalancer/net/NAME/ID"
            echo "   4. Set: export NLB_FULL_NAME='net/NAME/ID'"
            errors=$((errors + 1))
        fi
    else
        # Validate format: net/name/id
        if [[ ! "$NLB_FULL_NAME" =~ ^net/.+/.+ ]]; then
            echo "❌ ERROR: NLB_FULL_NAME must be in format 'net/NAME/ID'"
            echo "   Got: $NLB_FULL_NAME"
            errors=$((errors + 1))
        else
            echo "✅ NLB_FULL_NAME: $NLB_FULL_NAME"
        fi
    fi
    
    if [ -z "$WEBHOOK_URL" ]; then
        echo "❌ ERROR: WEBHOOK_URL is required"
        echo "   Example: export WEBHOOK_URL='https://event-ai.us-east-1.api.aws/webhook/generic/YOUR-ID'"
        errors=$((errors + 1))
    else
        # Validate URL format
        if [[ ! "$WEBHOOK_URL" =~ ^https?:// ]]; then
            echo "❌ ERROR: WEBHOOK_URL must start with http:// or https://"
            echo "   Got: $WEBHOOK_URL"
            errors=$((errors + 1))
        else
            echo "✅ WEBHOOK_URL: ${WEBHOOK_URL:0:50}..."
        fi
    fi
    
    if [ -z "$WEBHOOK_SECRET" ]; then
        echo "❌ ERROR: WEBHOOK_SECRET is required"
        echo "   Example: export WEBHOOK_SECRET='YOUR-SECRET-KEY'"
        errors=$((errors + 1))
    else
        echo "✅ WEBHOOK_SECRET: [REDACTED]"
    fi
    
    # Conditional validation
    if [ "$ENABLE_ROUTE53" = "true" ] && [ -z "$NLB_DNS_NAME" ]; then
        echo "⚠️  WARNING: NLB_DNS_NAME is required when ENABLE_ROUTE53=true"
        echo "   Either set NLB_DNS_NAME or set ENABLE_ROUTE53=false"
        echo "   Example: export NLB_DNS_NAME='k8s-ui-ui-424a820845-....elb.us-west-2.amazonaws.com'"
        errors=$((errors + 1))
    elif [ -n "$NLB_DNS_NAME" ]; then
        echo "✅ NLB_DNS_NAME: $NLB_DNS_NAME"
    fi
    
    # Validate AUTH_TYPE
    if [[ ! "$AUTH_TYPE" =~ ^(HMAC|BEARER)$ ]]; then
        echo "❌ ERROR: AUTH_TYPE must be 'HMAC' or 'BEARER'"
        echo "   Got: $AUTH_TYPE"
        errors=$((errors + 1))
    else
        echo "✅ AUTH_TYPE: $AUTH_TYPE"
    fi
    
    # Optional variables
    echo "✅ PRIMARY_REGION: $PRIMARY_REGION"
    echo "✅ ENVIRONMENT_NAME: $ENVIRONMENT_NAME"
    echo "✅ ENABLE_ROUTE53: $ENABLE_ROUTE53"
    echo "✅ USE_SECRETS_MANAGER: $USE_SECRETS_MANAGER"
    
    if [ "$USE_SECRETS_MANAGER" = "true" ]; then
        echo "✅ SECRET_NAME: $SECRET_NAME"
    fi
    
    # Check AWS CLI
    if ! command -v aws &> /dev/null; then
        echo "❌ ERROR: AWS CLI is not installed"
        echo "   Install: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html"
        errors=$((errors + 1))
    else
        echo "✅ AWS CLI: $(aws --version | cut -d' ' -f1)"
    fi
    
    # Check AWS credentials
    if ! aws sts get-caller-identity &> /dev/null; then
        echo "❌ ERROR: AWS credentials not configured or invalid"
        echo "   Run: aws configure"
        errors=$((errors + 1))
    else
        ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
        echo "✅ AWS Account: $ACCOUNT_ID"
    fi
    
    echo ""
    
    if [ $errors -gt 0 ]; then
        echo "❌ Validation failed with $errors error(s)"
        echo ""
        echo "Quick fix:"
        echo "export NLB_FULL_NAME='net/YOUR-NLB-NAME/YOUR-NLB-ID'"
        echo "export WEBHOOK_URL='https://event-ai.us-east-1.api.aws/webhook/generic/YOUR-ID'"
        echo "export WEBHOOK_SECRET='YOUR-SECRET-KEY'"
        echo ""
        exit 1
    fi
    
    echo "✅ All validations passed"
    echo ""
}

# Run validation
validate_variables

echo "=== Deploying Monitoring Stack for EKS ==="
echo "Region: $PRIMARY_REGION"
echo "Environment: $ENVIRONMENT_NAME"
echo ""

# Step 1: Create IAM Role for Lambda
echo "Creating IAM role for Lambda..."
ROLE_NAME="${ENVIRONMENT_NAME}-devops-agent-webhook-lambda"

TRUST_POLICY=$(cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {"Service": "lambda.amazonaws.com"},
    "Action": "sts:AssumeRole"
  }]
}
EOF
)

aws iam create-role \
  --role-name "$ROLE_NAME" \
  --assume-role-policy-document "$TRUST_POLICY" \
  --region "$PRIMARY_REGION" 2>/dev/null || echo "Role already exists"

aws iam attach-role-policy \
  --role-name "$ROLE_NAME" \
  --policy-arn "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole" \
  --region "$PRIMARY_REGION"

ROLE_ARN=$(aws iam get-role --role-name "$ROLE_NAME" --query 'Role.Arn' --output text)
echo "IAM Role ARN: $ROLE_ARN"

# Wait for role to propagate
sleep 10

# Step 2: Package Lambda Code
echo "Packaging Lambda function..."
cd lambda-code
zip -q webhook-handler.zip webhook-handler.py
cd ..

# Step 3: Create Secrets Manager Secret (Optional)
if [ "$USE_SECRETS_MANAGER" = "true" ]; then
    echo "Creating Secrets Manager secret..."
    
    SECRET_VALUE=$(cat <<EOF
{
  "url": "$WEBHOOK_URL",
  "secret": "$WEBHOOK_SECRET",
  "type": "$AUTH_TYPE"
}
EOF
)
    
    aws secretsmanager create-secret \
      --name "$SECRET_NAME" \
      --description "AWS DevOps Agent webhook credentials" \
      --secret-string "$SECRET_VALUE" \
      --region "$PRIMARY_REGION" 2>/dev/null || \
    aws secretsmanager update-secret \
      --secret-id "$SECRET_NAME" \
      --secret-string "$SECRET_VALUE" \
      --region "$PRIMARY_REGION"
    
    SECRET_ARN=$(aws secretsmanager describe-secret \
      --secret-id "$SECRET_NAME" \
      --region "$PRIMARY_REGION" \
      --query 'ARN' --output text)
    
    echo "Secret ARN: $SECRET_ARN"
    
    # Add Secrets Manager read permission to IAM role
    SECRETS_POLICY=$(cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["secretsmanager:GetSecretValue"],
    "Resource": "$SECRET_ARN"
  }]
}
EOF
)
    
    aws iam put-role-policy \
      --role-name "$ROLE_NAME" \
      --policy-name "${ENVIRONMENT_NAME}-secrets-manager-access" \
      --policy-document "$SECRETS_POLICY" \
      --region "$PRIMARY_REGION"
    
    echo "Added Secrets Manager permissions to Lambda role"
else
    echo "Using environment variables for webhook credentials (set USE_SECRETS_MANAGER=true for production)"
fi

# Step 4: Skip SNS - CloudWatch will invoke Lambda directly
echo "Skipping SNS (CloudWatch will invoke Lambda directly)..."

# Step 5: Create Lambda Functions
echo "Creating Lambda functions..."
LAMBDA_NAME_PRIMARY="${ENVIRONMENT_NAME}-devops-agent-webhook"
LAMBDA_NAME_R53="${ENVIRONMENT_NAME}-devops-agent-webhook-r53"

# Set Lambda environment variables based on Secrets Manager usage
if [ "$USE_SECRETS_MANAGER" = "true" ]; then
    LAMBDA_ENV_VARS="Variables={USE_SECRETS_MANAGER=true,SECRET_NAME=$SECRET_NAME,AWS_REGION_SECRET=$PRIMARY_REGION}"
else
    LAMBDA_ENV_VARS="Variables={WEBHOOK_URL=$WEBHOOK_URL,WEBHOOK_SECRET=$WEBHOOK_SECRET,AUTH_TYPE=$AUTH_TYPE}"
fi

# Primary region Lambda
aws lambda create-function \
  --function-name "$LAMBDA_NAME_PRIMARY" \
  --runtime python3.12 \
  --role "$ROLE_ARN" \
  --handler webhook-handler.lambda_handler \
  --zip-file fileb://lambda-code/webhook-handler.zip \
  --timeout 30 \
  --memory-size 128 \
  --environment "$LAMBDA_ENV_VARS" \
  --region "$PRIMARY_REGION" 2>/dev/null || \
aws lambda update-function-code \
  --function-name "$LAMBDA_NAME_PRIMARY" \
  --zip-file fileb://lambda-code/webhook-handler.zip \
  --region "$PRIMARY_REGION"

# Wait for Lambda to become active before updating config
aws lambda wait function-active-v2 --function-name "$LAMBDA_NAME_PRIMARY" --region "$PRIMARY_REGION"

# Update environment variables if function already exists
aws lambda update-function-configuration \
  --function-name "$LAMBDA_NAME_PRIMARY" \
  --environment "$LAMBDA_ENV_VARS" \
  --region "$PRIMARY_REGION" >/dev/null 2>&1

LAMBDA_ARN_PRIMARY=$(aws lambda get-function \
  --function-name "$LAMBDA_NAME_PRIMARY" \
  --region "$PRIMARY_REGION" \
  --query 'Configuration.FunctionArn' --output text)

# us-east-1 Lambda (only if PRIMARY_REGION is not us-east-1)
if [ "$PRIMARY_REGION" != "us-east-1" ]; then
    aws lambda create-function \
      --function-name "$LAMBDA_NAME_R53" \
      --runtime python3.12 \
      --role "$ROLE_ARN" \
      --handler webhook-handler.lambda_handler \
      --zip-file fileb://lambda-code/webhook-handler.zip \
      --timeout 30 \
      --memory-size 128 \
      --environment "$LAMBDA_ENV_VARS" \
      --region us-east-1 2>/dev/null || \
    aws lambda update-function-code \
      --function-name "$LAMBDA_NAME_R53" \
      --zip-file fileb://lambda-code/webhook-handler.zip \
      --region us-east-1

    # Wait for Lambda to become active before updating config
    aws lambda wait function-active-v2 --function-name "$LAMBDA_NAME_R53" --region us-east-1

    # Update environment variables if function already exists
    aws lambda update-function-configuration \
      --function-name "$LAMBDA_NAME_R53" \
      --environment "$LAMBDA_ENV_VARS" \
      --region us-east-1 >/dev/null 2>&1

    LAMBDA_ARN_R53=$(aws lambda get-function \
      --function-name "$LAMBDA_NAME_R53" \
      --region us-east-1 \
      --query 'Configuration.FunctionArn' --output text)
    
    echo "Lambda (R53): $LAMBDA_ARN_R53"
else
    # When PRIMARY_REGION is us-east-1, use the same Lambda for both
    LAMBDA_ARN_R53="$LAMBDA_ARN_PRIMARY"
    echo "Using primary Lambda for Route 53 (same region)"
fi

echo "Lambda (Primary): $LAMBDA_ARN_PRIMARY"
echo "Lambda (R53): $LAMBDA_ARN_R53"

# Step 6: Grant CloudWatch Permission to Invoke Lambda
echo "Granting CloudWatch permissions..."
aws lambda add-permission \
  --function-name "$LAMBDA_NAME_PRIMARY" \
  --statement-id AllowCloudWatchInvoke \
  --action lambda:InvokeFunction \
  --principal lambda.alarms.cloudwatch.amazonaws.com \
  --source-account $(aws sts get-caller-identity --query Account --output text) \
  --region "$PRIMARY_REGION" 2>/dev/null || echo "Permission already exists"

# Only add permission for R53 Lambda if it's a different function
if [ "$PRIMARY_REGION" != "us-east-1" ]; then
    aws lambda add-permission \
      --function-name "$LAMBDA_NAME_R53" \
      --statement-id AllowCloudWatchInvoke \
      --action lambda:InvokeFunction \
      --principal lambda.alarms.cloudwatch.amazonaws.com \
      --source-account $(aws sts get-caller-identity --query Account --output text) \
      --region us-east-1 2>/dev/null || echo "Permission already exists"
fi

# Step 7: Create CloudWatch Alarms
echo "Creating CloudWatch alarm..."

# Only create Route 53 endpoint-down alarm
# (Removed NLB alarms: unhealthy-targets, no-healthy-targets, target-resets, unhealthy-routing)

echo "Skipping NLB alarms (only Route 53 alarm will be created)"

# Step 8: Create Route 53 Health Check (Optional)
if [ "$ENABLE_ROUTE53" = "true" ] && [ -n "$NLB_DNS_NAME" ]; then
    echo "Creating Route 53 health check..."
    
    HEALTH_CHECK_CONFIG=$(cat <<EOF
{
  "Type": "HTTP",
  "ResourcePath": "/",
  "FullyQualifiedDomainName": "$NLB_DNS_NAME",
  "Port": 80,
  "RequestInterval": 30,
  "FailureThreshold": 3,
  "MeasureLatency": true
}
EOF
)
    
    HEALTH_CHECK_ID=$(aws route53 create-health-check \
      --caller-reference "$(date +%s)" \
      --health-check-config "$HEALTH_CHECK_CONFIG" \
      --query 'HealthCheck.Id' --output text 2>/dev/null || echo "")
    
    if [ -n "$HEALTH_CHECK_ID" ]; then
        echo "Health Check ID: $HEALTH_CHECK_ID"
        
        # Route 53 Endpoint Down Alarm
        ALARM_REGION="us-east-1"
        LAMBDA_ARN_FOR_ALARM="$LAMBDA_ARN_R53"
        
        # If PRIMARY_REGION is us-east-1, create alarm in same region
        if [ "$PRIMARY_REGION" = "us-east-1" ]; then
            ALARM_REGION="$PRIMARY_REGION"
            LAMBDA_ARN_FOR_ALARM="$LAMBDA_ARN_PRIMARY"
        fi
        
        aws cloudwatch put-metric-alarm \
          --alarm-name "${ENVIRONMENT_NAME}-ui-endpoint-down" \
          --alarm-description "Alert when UI kubernetes service's endpoint in the default namespace is not responding to health check HTTP requests from the LB" \
          --metric-name HealthCheckStatus \
          --namespace AWS/Route53 \
          --statistic Minimum \
          --period 60 \
          --evaluation-periods 2 \
          --threshold 1 \
          --comparison-operator LessThanThreshold \
          --dimensions Name=HealthCheckId,Value="$HEALTH_CHECK_ID" \
          --alarm-actions "$LAMBDA_ARN_FOR_ALARM" \
          --treat-missing-data breaching \
          --region "$ALARM_REGION"
        
        echo "Created Route 53 health check alarm in $ALARM_REGION"
    fi
fi

echo ""
echo "=== Deployment Complete ==="
echo "Lambda (Primary): $LAMBDA_ARN_PRIMARY"
echo "Lambda (R53): $LAMBDA_ARN_R53"
echo ""
echo "Test alarm with:"
echo "aws cloudwatch set-alarm-state --alarm-name ${ENVIRONMENT_NAME}-ui-endpoint-down --state-value ALARM --state-reason 'Test' --region us-east-1"

# Cleanup
rm -f lambda-code/webhook-handler.zip
