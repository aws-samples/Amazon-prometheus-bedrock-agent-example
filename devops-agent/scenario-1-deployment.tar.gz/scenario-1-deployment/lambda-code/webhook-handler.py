import json
import os
import urllib3
import hmac
import hashlib
import base64
from datetime import datetime

http = urllib3.PoolManager()

def get_webhook_config():
    """
    Get webhook configuration from environment variables or Secrets Manager.
    """
    use_secrets_manager = os.environ.get('USE_SECRETS_MANAGER', 'false').lower() == 'true'
    
    if use_secrets_manager:
        import boto3
        
        secret_name = os.environ['SECRET_NAME']
        # Use AWS_REGION_SECRET if set, otherwise use Lambda's AWS_REGION (always set by Lambda runtime)
        region = os.environ.get('AWS_REGION_SECRET', os.environ['AWS_REGION'])
        
        client = boto3.client('secretsmanager', region_name=region)
        response = client.get_secret_value(SecretId=secret_name)
        secret_data = json.loads(response['SecretString'])
        
        return {
            'url': secret_data['url'],
            'secret': secret_data['secret'],
            'auth_type': secret_data.get('type', 'HMAC')
        }
    else:
        return {
            'url': os.environ['WEBHOOK_URL'],
            'secret': os.environ['WEBHOOK_SECRET'],
            'auth_type': os.environ.get('AUTH_TYPE', 'HMAC')
        }

def lambda_handler(event, context):
    """
    Lambda function to trigger AWS DevOps Agent investigation via webhook
    when CloudWatch alarm triggers directly (no SNS).
    """
    
    # Log the raw event for debugging
    print(f"Raw event: {json.dumps(event)}")
    
    # Get webhook configuration
    webhook_config = get_webhook_config()
    webhook_url = webhook_config['url']
    webhook_secret = webhook_config['secret']
    auth_type = webhook_config['auth_type']
    
    # Parse CloudWatch alarm event (direct invocation)
    alarm_data = event.get('alarmData', {})
    state = alarm_data.get('state', {})
    configuration = alarm_data.get('configuration', {})
    
    alarm_name = alarm_data.get('alarmName', 'Unknown')
    alarm_description = configuration.get('description', '')
    new_state = state.get('value', 'ALARM')
    reason = state.get('reason', '')
    region = event.get('region', context.invoked_function_arn.split(':')[3])
    timestamp = event.get('time', datetime.utcnow().isoformat())
    
    # Extract metric information
    metrics = configuration.get('metrics', [])
    if metrics:
        metric_stat = metrics[0].get('metricStat', {})
        metric = metric_stat.get('metric', {})
        metric_name = metric.get('name', 'Unknown')
        namespace = metric.get('namespace', 'Unknown')
    else:
        metric_name = 'Unknown'
        namespace = 'Unknown'
    
    # Create incident payload for DevOps Agent
    incident_id = f"{alarm_name}-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
    
    payload = {
        "eventType": "incident",
        "incidentId": incident_id,
        "action": "created",
        "priority": "HIGH",
        "title": f"CloudWatch Alarm: {alarm_name}",
        "description": f"{alarm_description}\n\nAlarm State: {new_state}\nReason: {reason}\nMetric: {namespace}/{metric_name}\nRegion: {region}",
        "timestamp": timestamp,
        "service": alarm_name,
        "data": {
            "metadata": {
                "region": region,
                "environment": "production",
                "alarmName": alarm_name,
                "metricName": metric_name,
                "namespace": namespace,
                "newState": new_state
            }
        }
    }
    
    payload_json = json.dumps(payload)
    event_timestamp = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')
    
    # Prepare headers based on authentication type
    headers = {
        'Content-Type': 'application/json',
        'x-amzn-event-timestamp': event_timestamp
    }
    
    if auth_type == 'HMAC':
        # Generate HMAC signature
        message_to_sign = f"{event_timestamp}:{payload_json}"
        signature = hmac.new(
            webhook_secret.encode('utf-8'),
            message_to_sign.encode('utf-8'),
            hashlib.sha256
        ).digest()
        signature_b64 = base64.b64encode(signature).decode('utf-8')
        headers['x-amzn-event-signature'] = signature_b64
    else:  # BEARER
        headers['Authorization'] = f'Bearer {webhook_secret}'
    
    # Send webhook request
    try:
        response = http.request(
            'POST',
            webhook_url,
            body=payload_json,
            headers=headers
        )
        
        print(f"Webhook response status: {response.status}")
        print(f"Webhook response body: {response.data.decode('utf-8')}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Webhook sent successfully',
                'incidentId': incident_id,
                'webhookStatus': response.status
            })
        }
    except Exception as e:
        print(f"Error sending webhook: {str(e)}")
        raise
