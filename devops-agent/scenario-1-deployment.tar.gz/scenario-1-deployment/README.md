# EKS Monitoring Stack - AWS CLI Deployment

Deploy CloudWatch alarms and Lambda functions to trigger AWS DevOps Agent investigations when your EKS application has issues.

## Prerequisites

- AWS CLI v2 installed and configured
- Existing EKS cluster with NLB (from ui service)
- AWS DevOps Agent webhook credentials

## What Gets Deployed

- **1 CloudWatch Alarm** - Monitors Route 53 endpoint health
- **1 Lambda Function** - Triggers DevOps Agent when alarm fires
- **1 Route 53 Health Check** - HTTP endpoint monitoring
- **1 IAM Role** - Lambda execution permissions
- **1 Secrets Manager Secret** - Secure credential storage

## Quick Start

```bash
# 1. Set your DevOps Agent webhook credentials
export WEBHOOK_URL="https://event-ai.us-east-1.api.aws/webhook/generic/YOUR-ID"
export WEBHOOK_SECRET="YOUR-SECRET-KEY"

# 2. Deploy (auto-discovers your NLB)
./deploy.sh

# 3. Test the setup
aws cloudwatch set-alarm-state \
  --alarm-name retail-store-ui-endpoint-down \
  --state-value ALARM \
  --state-reason "Test" \
  --region us-east-1
```

That's it! The script automatically discovers your NLB, stores credentials securely in Secrets Manager, and sets up monitoring.

### Optional: Override Defaults

```bash
export PRIMARY_REGION="us-west-2"              # Default: us-west-2
export ENVIRONMENT_NAME="retail-store"         # Default: retail-store
export AUTH_TYPE="HMAC"                        # Default: HMAC
export ENABLE_ROUTE53="true"                   # Default: true
export USE_SECRETS_MANAGER="false"             # Default: true (set false for demos only)
```

### Optional: Set NLB Manually

If auto-discovery fails, get NLB details:

```bash
# From kubectl
kubectl get svc -n ui ui -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'

# From AWS CLI
aws elbv2 describe-load-balancers --region us-west-2

# Set manually (extract net/NAME/ID from ARN)
export NLB_FULL_NAME="net/YOUR-NLB-NAME/YOUR-NLB-ID"
```

## How It Works

```
CloudWatch Alarm → Lambda Function → DevOps Agent Webhook
```

When an alarm triggers, Lambda sends incident details to DevOps Agent which automatically investigates the issue.

**Why 2 Lambda functions?**
- Primary region (us-west-2): Handles 4 NLB alarms
- us-east-1: Handles Route 53 alarm (Route 53 metrics only exist in us-east-1)

**No SNS needed:** CloudWatch alarms invoke Lambda directly for simplicity.

## Testing

```bash
# Watch Lambda logs
aws logs tail /aws/lambda/retail-store-devops-agent-webhook --follow --region us-west-2

# Check DevOps Agent console for the investigation
```

## Cleanup

```bash
./cleanup.sh
```

Removes all deployed resources.

## Troubleshooting

**Lambda not triggering?**
```bash
aws lambda get-policy --function-name retail-store-devops-agent-webhook --region us-west-2
```

**Webhook failing?**
Check Lambda logs for HTTP errors. Verify webhook URL and secret are correct.

## Architecture Notes

**Single Lambda function:** Handles Route 53 health check alarm in the primary region.

**No SNS needed:** CloudWatch alarm invokes Lambda directly for simplicity.

## Production Use

By default, credentials are stored securely in AWS Secrets Manager (encrypted at rest, not visible in Lambda console).

For demos/development only, you can disable Secrets Manager:

```bash
export USE_SECRETS_MANAGER="false"  # Not recommended for production
./deploy.sh
```
