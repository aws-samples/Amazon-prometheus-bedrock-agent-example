#!/bin/bash
set -e

# Configuration Variables
PRIMARY_REGION="${PRIMARY_REGION:-us-west-2}"
ENVIRONMENT_NAME="${ENVIRONMENT_NAME:-retail-store}"
SECRET_NAME="${SECRET_NAME:-${ENVIRONMENT_NAME}/devops-agent/webhook}"

echo "=== Cleaning Up Monitoring Stack ==="
echo "Region: $PRIMARY_REGION"
echo "Environment: $ENVIRONMENT_NAME"

# Step 1: Delete CloudWatch Alarms
echo "Deleting CloudWatch alarm..."
aws cloudwatch delete-alarms \
  --alarm-names "${ENVIRONMENT_NAME}-ui-endpoint-down" \
  --region "$PRIMARY_REGION" 2>/dev/null || echo "Alarm not found in $PRIMARY_REGION"

# Delete Route 53 alarm in us-east-1 only if PRIMARY_REGION is not us-east-1
if [ "$PRIMARY_REGION" != "us-east-1" ]; then
    aws cloudwatch delete-alarms \
      --alarm-names "${ENVIRONMENT_NAME}-ui-endpoint-down" \
      --region us-east-1 2>/dev/null || echo "Alarm not found in us-east-1"
fi

# Step 2: Delete Route 53 Health Check
echo "Deleting Route 53 health checks..."
HEALTH_CHECKS=$(aws route53 list-health-checks \
  --query "HealthChecks[?HealthCheckConfig.FullyQualifiedDomainName && contains(HealthCheckConfig.FullyQualifiedDomainName, 'elb')].Id" \
  --output text 2>/dev/null || echo "")

for HC_ID in $HEALTH_CHECKS; do
    aws route53 delete-health-check --health-check-id "$HC_ID" 2>/dev/null || echo "Could not delete $HC_ID"
done

# Step 3: Delete Lambda Functions
echo "Deleting Lambda functions..."
aws lambda delete-function \
  --function-name "${ENVIRONMENT_NAME}-devops-agent-webhook" \
  --region "$PRIMARY_REGION" 2>/dev/null || echo "Lambda not found in $PRIMARY_REGION"

# Delete R53 Lambda only if PRIMARY_REGION is not us-east-1
if [ "$PRIMARY_REGION" != "us-east-1" ]; then
    aws lambda delete-function \
      --function-name "${ENVIRONMENT_NAME}-devops-agent-webhook-r53" \
      --region us-east-1 2>/dev/null || echo "R53 Lambda not found in us-east-1"
fi

# Step 4: Detach and Delete IAM Role
echo "Deleting IAM role..."
ROLE_NAME="${ENVIRONMENT_NAME}-devops-agent-webhook-lambda"

# Remove inline policy if exists
aws iam delete-role-policy \
  --role-name "$ROLE_NAME" \
  --policy-name "${ENVIRONMENT_NAME}-secrets-manager-access" \
  --region "$PRIMARY_REGION" 2>/dev/null || echo "No inline policy found"

aws iam detach-role-policy \
  --role-name "$ROLE_NAME" \
  --policy-arn "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole" \
  --region "$PRIMARY_REGION" 2>/dev/null || echo "Policy already detached"

aws iam delete-role \
  --role-name "$ROLE_NAME" \
  --region "$PRIMARY_REGION" 2>/dev/null || echo "Role not found"

# Step 5: Delete Secrets Manager Secret (if exists)
echo "Deleting Secrets Manager secret..."
aws secretsmanager delete-secret \
  --secret-id "$SECRET_NAME" \
  --force-delete-without-recovery \
  --region "$PRIMARY_REGION" 2>/dev/null || echo "Secret not found"

# Step 6: Clean up local files
echo "Cleaning up local files..."
rm -f lambda-code/webhook-handler.zip

echo ""
echo "=== Cleanup Complete ==="
